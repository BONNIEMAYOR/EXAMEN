import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  final list = const ['Pato', 'Gato', 'Maria'];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text("El mundo de las maravillas"),
        ),
        body: ListView(
          children: [
            ...list.map((e) => ListTile(
              leading: const Icon(Icons.people_rounded),
              title: Text(e),
              trailing: const Icon(Icons.arrow_forward_ios_outlined),
            ), 
            )
          ],
        )
        ),
      );
  }
}
