import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Inicio')),
      body: Column(
        children: [
          ListTile(
            title: Text('Módulo de Proveedores'),
            onTap: () {
              Navigator.pushNamed(context, '/providers');
            },
          ),
          ListTile(
            title: Text('Módulo de Categorías'),
            onTap: () {
              Navigator.pushNamed(context, '/categories');
            },
          ),
          ListTile(
            title: Text('Módulo de Productos'),
            onTap: () {
              Navigator.pushNamed(context, '/products');
            },
          ),
        ],
      ),
    );
  }
}
