package com.example.proyecto_bonnie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
