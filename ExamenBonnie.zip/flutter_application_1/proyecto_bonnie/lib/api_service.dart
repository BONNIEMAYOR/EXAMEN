import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String _baseUrl = "http://143.198.118.203:8100"; 

  // CRUD para Productos
  Future<List<dynamic>> fetchProducts() async {
    final response = await http.get(Uri.parse('$_baseUrl/ejemplos/product_list_rest/'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Error al cargar productos');
    }
  }

  Future<void> addProduct(String name, double price, String image) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/product_add_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'product_name': name,
        'product_price': price,
        'product_image': image,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al agregar producto');
    }
  }

  Future<void> editProduct(int id, String name, double price, String image, String state) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/product_edit_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'product_id': id,
        'product_name': name,
        'product_price': price,
        'product_image': image,
        'product_state': state,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al editar producto');
    }
  }

  Future<void> deleteProduct(int id) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/product_del_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'product_id': id,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al eliminar producto');
    }
  }

  // CRUD para Categorías
  Future<List<dynamic>> fetchCategories() async {
    final response = await http.get(Uri.parse('$_baseUrl/ejemplos/category_list_rest/'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Error al cargar categorías');
    }
  }

  Future<void> addCategory(String name) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/category_add_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'category_name': name,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al agregar categoría');
    }
  }

  Future<void> editCategory(int id, String name, String state) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/category_edit_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'category_id': id,
        'category_name': name,
        'category_state': state,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al editar categoría');
    }
  }

  Future<void> deleteCategory(int id) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/category_del_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'category_id': id,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al eliminar categoría');
    }
  }

  // CRUD para Proveedores
  Future<List<dynamic>> fetchProviders() async {
    final response = await http.get(Uri.parse('$_baseUrl/ejemplos/provider_list_rest/'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Error al cargar proveedores');
    }
  }

  Future<void> addProvider(String name, String lastName, String email) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/provider_add_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'provider_name': name,
        'provider_last_name': lastName,
        'provider_mail': email,
        'provider_state': 'Activo',
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al agregar proveedor');
    }
  }

  Future<void> editProvider(int id, String name, String lastName, String email) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/provider_edit_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'provider_id': id,
        'provider_name': name,
        'provider_last_name': lastName,
        'provider_mail': email,
        'provider_state': 'Activo',
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al editar proveedor');
    }
  }

  Future<void> deleteProvider(int id) async {
    final response = await http.post(
      Uri.parse('$_baseUrl/ejemplos/provider_del_rest/'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: json.encode({
        'provider_id': id,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Error al eliminar proveedor');
    }
  }
}
