import 'package:flutter/material.dart';

class CategoriesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Simulación de categorias
    final List<String> categories= ['Categoria 1', 'Categoria 2', 'Categoria 3'];

    return Scaffold(
      appBar: AppBar(title: Text('Categorias')),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(categories[index]),
            onTap: () {
              Navigator.pushNamed(context, '/provider-detail', arguments: categories[index]);
            },
          );
        },
      ),
    );
  }
}
