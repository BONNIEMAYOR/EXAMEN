import 'package:flutter/material.dart';

class ProvidersScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Simulación de proveedores
    final List<String> providers = ['Proveedor 1', 'Proveedor 2', 'Proveedor 3'];

    return Scaffold(
      appBar: AppBar(title: Text('Proveedores')),
      body: ListView.builder(
        itemCount: providers.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(providers[index]),
            onTap: () {
              Navigator.pushNamed(context, '/provider-detail', arguments: providers[index]);
            },
          );
        },
      ),
    );
  }
}
